<template>
  <div class="home">
    <div class="container">
      <div class="home__category">
        <i data-feather="circle"></i>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',
}
</script>
