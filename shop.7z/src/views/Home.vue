<template>
  <div class="home">
    main coвапвапвапвапвап
  </div>
</template>

<script>
export default {
  name: 'Home',
}
</script>
