<template>
  <div>
    Избранное
  </div>
</template>

<script>
export default {
  name: 'favorite'
}
</script>

<style lang="scss" scoped>

</style>