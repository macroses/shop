<template>
  <div>
    Корзина
  </div>
</template>

<script>
export default {
  name: "store"
}
</script>

<style lang="scss" scoped>

</style>