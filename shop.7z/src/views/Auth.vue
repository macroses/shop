<template>
  <div>
    Авторизация
  </div>
</template>

<script>
export default {
  name: 'Auth'
}
</script>

<style lang="scss" scoped>

</style>