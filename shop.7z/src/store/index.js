import { createStore } from 'vuex'

export default createStore({
  state: {
    favorites: []
  },
  getters: {
    favorites: state => state.favorites
  },
  mutations: {
    APPEND_FAVORITE(state, favorite) {
      state.favorites = [...state.favorites, favorite]
    }
  },
  actions: {
    addFavorite(state, id) {
      state.commit('APPEND_FAVORITE', id)
    }
  }
})
